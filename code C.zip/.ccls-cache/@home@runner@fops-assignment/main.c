#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

int small_available[] = {1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008,
                         1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016,
                         1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024,
                         1025, 1026, 1027, 1028, 1029, 1030};
int medium_available[] = {2001, 2002, 2003, 2004, 2005, 2006, 2007,
                          2008, 2009, 2010, 2011, 2012, 2013, 2014,
                          2015, 2016, 2017, 2018, 2019, 2020};
int large_available[] = {3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009,
                         3010, 3011, 3012, 3013, 3014, 3015, 3016, 3017, 3018,
                         3019, 3020, 3021, 3022, 3023, 3024, 3025};


int small_rented[30]={0};
int medium_rented[20]={0};
int large_rented[25]={0};


int small_returned[]={};
int medium_returned[]={};
int large_returned[]={};

int small_lost[30]={};
int medium_lost[20]={};
int large_lost[25]={};


// function which is used in rented function. we are using this one to transfer value from available to rented.arguments following in function source,destination,destination araay size

void transfer_available_to_rented(int value,int array[],int array_size)
{
int index=0;
  while (array[index] != 0 && index < array_size)
  {
   index++;
  }
    if (index < array_size) 
    {
        array[index] = value;
    }
}

// variables used in rented function
int rented_menu_user_choice, rented_user_selected_sn, rented_user_payment, rented_second_user_choice;


void rented_shoes() 
{

  
  // display the sizes menu for rented
  printf("\n\n\nPlease select the size you want to rent\n");
  printf("\nPress 1 for Small  1xxx to 1030");
  printf("\nPress 2 for Medium 2xxx to 2020");
  printf("\nPress 3 for Large  3xxx to 3025");
  printf("\nPress 4 for Exit to Main Menu\n");


  // variables declaration which are used in this rented function
  int rented_menu_user_choice, rented_user_selected_sn, rented_user_payment, rented_second_user_choice;
  scanf("%d", &rented_menu_user_choice);

  if (rented_menu_user_choice == 1) 
  {
    // display shoe sizes which are available
    printf("\nFor Small Shoes,\nThe available sizes to rent are:\n");
    for (int i = 0; i <= 29; i++) 
    {
      printf("\n %d", small_available[i]);
    }
     
    // display serial numbers
    printf("\n\n\nEnter the serial number you wish to rent:");

    // takes user selected serial numbers
    int rented_user_selected_sn;
    scanf("%d", &rented_user_selected_sn);

    // if statement to check the value entered, if its valid or not 
    if (rented_user_selected_sn >= 1001 && rented_user_selected_sn <= 1030)
    {
      int rented_user_payment;

      // 5 pounds deposit as security factor
      printf(" \n\nFor security measures:You have to pay £5 to gain the access "
             "to your selected shoe %d,you can gain your deposited money back "
             "once you return the shoe.   ",
             rented_user_selected_sn);

      printf("\n\nPlease press 5 to provide the payment ");
      scanf("%d", &rented_user_payment);

      
      if (rented_user_payment == 5) 
      {
        
        //another function which will gonna transfer values from avialble to rented..
        
        transfer_available_to_rented(rented_user_selected_sn,small_rented,30);
        printf("\n%d is rented to you,dont forget to return it back. ",rented_user_selected_sn);


         for(int i=0;i<30;i++)
          {
        printf("\n %d",small_rented[i]);
          }

         // asks from user if they need to rent another shoe
           printf("\n\nWould you like to rent another shoe?");
           printf("\n Type 1 for Yes");
           printf("\n Type 0 for No");
           
           int rented_second_user_choice;
           scanf("%d", &rented_second_user_choice);
             
           if(rented_second_user_choice = 1)
           {
            rented_shoes();
           }
           else
           {
           return -1;
           }
        
      }
      else if (rented_user_payment != 5) 
      {
        printf("\nInvalid rseponse:shoe cant be rented");
        rented_shoes();
      }

    }
// when shoe in unavailable,either rented before or wrong input
    else {
      printf("Unfortunately, selected shoe %d is unavailable",
             rented_user_selected_sn);
        rented_shoes();
      
    }
  }

    
  else if (rented_menu_user_choice == 2) 
  {
    printf("For Medium Shoes,\nThe available sizes to rent are:");
    for (int i = 0; i <= 19; i++) 
     {
      printf("\n %d", medium_available[i]);
     }
      printf("\n\n\nEnter the serial number you wish to rent:");
      
    int rented_user_selected_sn;
    scanf("%d", &rented_user_selected_sn);
    if (rented_user_selected_sn >= 2001 && rented_user_selected_sn <= 2020) 
    {
      int rented_user_payment;

      printf(" \n\nFor security measures:You have to pay £5 to gain the access "
             "to your selected shoe %d,you can gain your deposited money back "
             "once you return the shoe.   ",
             rented_user_selected_sn);

      printf("\n\nPlease press 5 to provide the payment ");
      scanf("%d", &rented_user_payment);
      
      if (rented_user_payment == 5) 
      {

        transfer_available_to_rented(rented_user_selected_sn,medium_rented,20);
        printf("\n%d is rented to you,dont forget to return it back. ",rented_user_selected_sn);


         for(int i=0;i<20;i++)
          {
        printf("\n%d",medium_rented[i]);
          }

         // asks from user if they need to rent another shoe
           printf("\n\nWould you like to rent another shoe?");
           printf("\n Type 1 for Yes");
           printf("\n Type 0 for No");
           
           int rented_second_user_choice;
           scanf("%d", &rented_second_user_choice);
        
          if(rented_second_user_choice = 1)
           {
            rented_shoes();
           }
           else
           {
           return -1;
           }


        
      } 
      else if (rented_user_payment != 5) 
      {
        printf("\nInvalid rseponse:shoe cant be rented");
        rented_shoes();
        
      }

    }

    else {
      printf("Unfortunately, selected shoe %d is unavailable",
             rented_user_selected_sn);
        rented_shoes();
      
    }
  }


else if(rented_menu_user_choice == 3) 
{
printf("For Large Shoes,\nThe available sizes to rent are:");
    for (int i = 0; i <= 24; i++) 
    {
      printf("\n %d", large_available[i]);
    }
    printf("\n\n\nEnter the serial number you wish to rent:");
    int rented_user_selected_sn;
    scanf("%d", &rented_user_selected_sn);
    if (rented_user_selected_sn >= 3001 && rented_user_selected_sn <= 3025) 
    {
      int rented_user_payment;

      printf(" \n\nFor security measures:You have to pay £5 to gain the access "
             "to your selected shoe %d,you can gain your deposited money back "
             "once you return the shoe.   ",
             rented_user_selected_sn);

      printf("\n\nPlease press 5 to provide the payment ");
      scanf("%d", &rented_user_payment);
      
      if (rented_user_payment == 5) 
      {
      
        transfer_available_to_rented(rented_user_selected_sn,large_rented,25);
        printf("\n%d is rented to you,dont forget to return it back. ",rented_user_selected_sn);
        
         for(int i=0;i<25;i++)
          {
        printf("\n %d",large_rented[i]);
          }

         // asks from user if they need to rent another shoe
           printf("\n\nWould you like to rent another shoe?");
           printf("\n Type 1 for Yes");
           printf("\n Type 0 for No");
           
           int rented_second_user_choice;
           scanf("%d", &rented_second_user_choice);
             
           if(rented_second_user_choice = 1)
           {
            rented_shoes();
           }
           else
           {
           return -1;
           }
        
      } 
      else if (rented_user_payment != 5) 
      {
        printf("\nInvalid rseponse:shoe cant be rented");
        rented_shoes();
      }
    }
}

else if (rented_menu_user_choice == 4) 
{
  printf("Press any key to exit.");
  return 0;
}

else 
{
  printf("Wrong Choice");
  rented_shoes();
}
}


// arguments are 1st the serial number which needs to be returned, 2nd the array which needs to be checked and where value would be stored, 3rd size of array which needs to be checked
void remove_value_rented_to_available(int value, int array[], int arraySize )
{
    int ii, jj;
       int match = 0;
       for (ii = 0; ii < arraySize; ii++) 
       {
        if (array[ii] == value) 
        {
           match = 1;
            break;
        }
       }
       if  (match == 1) 
       {
        for (jj = ii; jj < arraySize - 1; jj++) 
         {
            array[jj] = array[jj+1];
         }
        arraySize--;
       }
}

void return_shoes()
{
  // display the sizes, which can be returned
  printf("\n\n\nPlease select the size you want to return.\n");
  printf("\nPress 1 for Small  1xxx to 1030");
  printf("\nPress 2 for Medium 2xxx to 2020");
  printf("\nPress 3 for Large  3xxx to 3025");
  printf("\nPress 4 for Exit to Main Menu\n");


  // variables declaration which are used in this rented function
  int returned_menu_user_choice, returned_user_entered_sn, returned_user_payment, return_second_user_choice;
  scanf("%d", &returned_menu_user_choice);

  if (returned_menu_user_choice == 1)
  {
    printf("\n\nPlease enter the serial number you want to return");
    scanf("%d", &returned_user_entered_sn);
    
     if(returned_user_entered_sn>=1001 && returned_user_entered_sn <=1030)
      {
        // function to check and remove value from rented array
       remove_value_rented_to_available(returned_user_entered_sn, small_rented,30 );

        // Shoe Removal Confirmation
       printf("\n\n\n\nShoe with the serial number:%d is returned back.Thanks for using our service.",returned_user_entered_sn);

        // Money Rebate
       printf("\n\nPress 5 to claim back your deposited money");
        scanf("%d", &returned_user_payment);

          if(returned_user_payment==5)
           {
           printf("\nMoney transfered successfully.");
           } 
           else
           {
           printf("\nUnknown response");
             return_shoes();
           }
        
               // asks from user if they need to return another shoe
           printf("\n\n\n\nWould you like to return any another shoe?");
           printf("\n\n Press 1 if you want to return any other shoe");
           printf("\n Press 0 to return back to Main Menu");
           
           int return_second_user_choice;
           scanf("%d", &return_second_user_choice);
             
           if(return_second_user_choice = 1)
           {
            return_shoes();
           }
           else
           {
           return -1;
           }
      
      }
      
     else
     {
       printf("Invalid number entered");
       return_shoes();
     }
  }
  
  if (returned_menu_user_choice == 2)
  {
    printf("\n\nPlease enter the serial number you want to return");
      scanf("%d", &returned_user_entered_sn);
      
     if(returned_user_entered_sn>=2001 && returned_user_entered_sn <=2020)
     {
       // function to check and remove value from rented array
       remove_value_rented_to_available(returned_user_entered_sn, medium_rented,20 );

        // Shoe Removal Confirmation
       printf("\n\n\n\nShoe with the serial number:%d is returned back.Thanks for using our service.",returned_user_entered_sn);

        // Money Rebate
       printf("\n\nPress 5 to claim back your deposited money");
        scanf("%d", &returned_user_payment);

          if(returned_user_payment==5)
           {
           printf("\nMoney transfered successfully.");
           } 
           else
           {
           printf("\nUnknown response");
             return_shoes();
           }
        
               // asks from user if they need to return another shoe
           printf("\n\n\n\nWould you like to return any another shoe?");
           printf("\n\n Press 1 if you want to return any other shoe");
           printf("\n Press 0 to return back to Main Menu");
           
           int return_second_user_choice;
           scanf("%d", &return_second_user_choice);
             
           if(return_second_user_choice = 1)
           {
            return_shoes();
           }
           else
           {
           return -1;
           }
     }
     else
     {
       printf("Invalid number entered");
       return_shoes();
     }
  }
  
  if (returned_menu_user_choice == 3) 
  {
    printf("\n\nPlease enter the serial number you want to return");
      scanf("%d", &returned_user_entered_sn);
     if(returned_user_entered_sn>=3001 && returned_user_entered_sn <=3025)
    {
       // function to check and remove value from rented array
       remove_value_rented_to_available(returned_user_entered_sn, small_rented,30 );

        // Shoe Removal Confirmation
       printf("\n\n\n\nShoe with the serial number:%d is returned back.Thanks for using our service.",returned_user_entered_sn);

        // Money Rebate
        printf("\n\nPress 5 to claim back your deposited money");
        scanf("%d", &returned_user_payment);

          if(returned_user_payment==5)
           {
           printf("\nMoney transfered successfully.");
           } 
           else
           {
           printf("\nUnknown response");
             return_shoes();
           }
        
               // asks from user if they need to return another shoe
           printf("\n\n\n\nWould you like to return any another shoe?");
           printf("\n\n Press 1 if you want to return any other shoe");
           printf("\n Press 0 to return back to Main Menu");
           
           int return_second_user_choice;
           scanf("%d", &return_second_user_choice);
             
           if(return_second_user_choice = 1)
           {
            return_shoes();
           }
           else
           {
           return -1;
           }
    }
     else
    {
       printf("Invalid number entered");
       return_shoes();
    }
  }
  
  if (returned_menu_user_choice == 4)
  {
      printf("Press any key to exit.");
  return 0;
  }
 else 
 {
  printf("Wrong Choice");
   return_shoes();
 }

}

// first argument takes the serial number, second argument checks ig serial number is in rented array,3rd argument is the lost array where shoe would be added if found , 4th is suze of rented array, 5th is also size
void rented_to_lost(int serial_num, int* rented, int* lost, int sizeofrented, int sizeoflost) 
{
    // Find the index of the value in the first array
    int index = -1;
    for (int i = 0; i < sizeofrented; i++) 
    {
        if (rented[i] == serial_num) 
        {
            index = i;
            break;
        }
    }

    // If the value is found, remove it from the first array and add it to the second array
    if (index != -1) 
    {
        lost[sizeoflost] = rented[index];
        sizeoflost++;
        for (int i = index; i < sizeofrented - 1; i++)
        {
            rented[i] = rented[i+1];
        }
        sizeofrented--;
    }
}

void lost_shoes() 
{

  int lost_user_menu_response, lost_user_entered_sn;

  // display the sizes menu for rented
  printf("\n\n\nKindly choose the shoe size that you would like to report as "
         "lost.\n");
  printf("\nPress 1 for Small  1xxx to 1030");
  printf("\nPress 2 for Medium 2xxx to 2020");
  printf("\nPress 3 for Large  3xxx to 3025");
  printf("\nPress 4 for Exit to Main Menu\n");

  scanf("%d", &lost_user_menu_response);

  if (lost_user_menu_response == 1) 
  {
    printf("\n\nFor the Small Shoes ");
    printf("\nPlease enter the serial number you want to report as lost");
    scanf("%d", &lost_user_entered_sn);

    if (lost_user_entered_sn >= 1001 && lost_user_entered_sn <= 1030) 
    {
      rented_to_lost(lost_user_entered_sn, small_rented , small_lost ,30 ,30 );

      printf("\n %d is marked as lost shoe.", &lost_user_entered_sn);
      printf("\nThank you for taking the time to report the lost shoe.");
      
    }
    else
    {
      printf("Invalid value entered");
      lost_shoes();
    }
  }

  else if (lost_user_menu_response == 2) 
  {
    printf("\n\nFor the Medium Shoes ");
    printf("\nPlease enter the serial number you want to report as lost");
    scanf("%d", &lost_user_entered_sn);

    if (lost_user_entered_sn >= 2001 && lost_user_entered_sn <= 2020) 
    {
      rented_to_lost(lost_user_entered_sn, medium_rented , medium_lost ,20 ,20 );
     
      printf("\n %d is marked as lost shoe.", &lost_user_entered_sn);
      printf("\nThank you for taking the time to report the lost shoe.");
      
    }
     else
    {
      printf("Invalid value entered");
      lost_shoes();
    }
  }
    
  else if (lost_user_menu_response == 3) 
  {
    printf("\n\nFor the Small Shoes ");
    printf("\nPlease enter the serial number you want to report as lost");
    scanf("%d", &lost_user_entered_sn);

    if (lost_user_entered_sn >= 3001 && lost_user_entered_sn <= 3020) 
    {
      rented_to_lost(lost_user_entered_sn, large_rented , large_lost ,25 ,25);
      
      printf("\n %d is marked as lost shoe.", lost_user_entered_sn);
      printf("\nThank you for taking the time to report the lost shoe.");
    }
     else
    {
      printf("Invalid value entered");
      lost_shoes();
    }
  } 
    
  else if (lost_user_menu_response == 4) 
  {
   printf("Press any key to exit.");
   return 0;
  }
 else 
 {
  printf("Wrong Choice");
  lost_shoes();
 }

}


void main_menu_display() {
  // welcome message
  printf("\n\n \t Welcome to BBB Bowling Alley");
  // MENU SELECTION
  printf("\n\n\nSelect any option from the display menu");

  bool flag = false;
  do {

    /*menu display and choices*/
    printf("\n\n-------------------------------------");

    // printf("\nSelect any Option please: ");

  // printf("\n The Display Menu is: \n 1)Rent Shoe. \n 2)Return Shoes. \n 3)Lost Shoes. \n 4)View Rented in Each size. \n 5)View Rented Overall.\n 6)View Not Rented in Each size. \n 7)View Not-Rented Overall.\n 8)Least Rented Shoe. \n 9)Most Rented Shoe. \n 10)Exit.");
    
    printf("\n\n\t\tThe Display Menu is:  ");
    printf("\n\n1)Rent Shoe.  ");
    printf("\n\n2)Return Shoes. ");
    printf("\n\n3)Lost Shoes.");
    printf("\n\n4)View Statistics");
    printf("\n\n5)View Popularity Report ");
    printf("\n6)Exit ");
    printf("\nSelect any Option from above please: ");

    printf("\n\n-------------------------------------");

    int User_Response;
    scanf("%d", &User_Response);

    switch (User_Response) {
    case 1:
      printf("\n\n\t\tRent shoe");
      rented_shoes();
      break;
    case 2:
      printf("\n\nReturn shoe");
      return_shoes();
      break;
    case 3:
      printf("\n\nLost shoe");
      lost_shoes();
      break;
    case 4:
      printf("View Statics");
      for (int i=0 ; i<30 ; i++)
      {
      printf("\n%d",small_rented[i]);
      }
      break;
    case 5:
      printf("View report");
      break;

    case 6:
      exit(0);

    default:
      printf("Wrong input,try again please");
      break;
    }
  } while (true);
}

void ViewStatistics();

int ShoesAvailable() {

  // int total_available = (small_available,medium_available,large_available);
  int total_available[75] = {
      1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011,
      1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022,
      1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 2001, 2002, 2003,
      2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014,
      2015, 2016, 2017, 2018, 2019, 2020, 3001, 3002, 3003, 3004, 3005,
      3006, 3007, 3008, 3009, 3010, 3011, 3012, 3013, 3014, 3015, 3016,
      3017, 3018, 3019, 3020, 3021, 3022, 3023, 3024, 3025};

  int i;
  for (i = 0; i >= 75; i++) {
    printf("%d\n", total_available[i]);
  }
}

void ViewStatics() {}

int main(void) {
  // welcome message
  // printf("\n\nWelcome to BBB Bowling Alley");

  main_menu_display();

  return 0;
}
